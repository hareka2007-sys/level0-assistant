import json, os, re, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
with open(ROOT / "knowledge_base.json", encoding="utf-8") as f:
    KB = json.load(f)

def norm(value):
    value=(value or "").lower().strip()
    for a,b in [("أ","ا"),("إ","ا"),("آ","ا"),("ة","ه"),("ى","ي")]:
        value=value.replace(a,b)
    value=re.sub(r"[^a-z0-9\u0600-\u06ff\s+.-]"," ",value)
    return re.sub(r"\s+"," ",value).strip()

def course_answer(c):
    p="، ".join(c.get("prerequisites",[])) or "لا يوجد متطلب سابق مذكور في البيانات المتاحة"
    return f"{c['code']} — {c['name']}\nالساعات المعتمدة: {c['credits']}\nالفصل: {c['semester']}\nالمتطلب السابق: {p}"

def local_search(question):
    q=norm(question)
    for c in KB.get("courses",[]):
        if norm(c["code"]) in q or norm(c["name"]) in q:
            return course_answer(c)
    words=[w for w in q.split() if len(w)>1]
    best=None; score_best=0
    for e in KB.get("entries",[]):
        score=0
        for k0 in e.get("keywords",[]):
            k=norm(k0)
            if k and k in q: score += 8 if " " in k else 5
            else: score += sum(1 for w in words if w in k or k in w)
        if score>score_best: best,score_best=e,score
    if best and score_best>=3: return best["answer"]
    return "مش لاقي إجابة مؤكدة في قاعدة المعلومات الحالية. مش هخمن في اللوائح أو المواعيد أو الدرجات. لو عندك ملف أو إعلان رسمي ابعته عشان نضيف المعلومة بمصدرها."

def gemini(question,key):
    model=os.environ.get("GEMINI_MODEL","gemini-2.5-flash")
    url=f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    context=json.dumps(KB,ensure_ascii=False)
    prompt=("أنت مساعد أكاديمي. استخدم قاعدة المعلومات فقط في الحقائق الخاصة بالجامعة. "
            "لا تخترع لوائح أو مواعيد أو درجات. إذا لم تجد الإجابة قل إنها غير متاحة.\n"
            f"قاعدة المعلومات:\n{context}\nسؤال الطالب:\n{question}")
    payload={"contents":[{"role":"user","parts":[{"text":prompt}]}]}
    req=urllib.request.Request(url,data=json.dumps(payload).encode(),headers={"Content-Type":"application/json"},method="POST")
    with urllib.request.urlopen(req,timeout=25) as r: data=json.loads(r.read().decode())
    return "".join(p.get("text","") for p in data.get("candidates",[{}])[0].get("content",{}).get("parts",[]) if "text" in p)

def response(status,obj):
    return {"statusCode":status,"headers":{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"},"body":json.dumps(obj,ensure_ascii=False)}

def handler(req):
    path=req.get("path","")
    if path.endswith("/data"):
        return response(200,{"courses":KB.get("courses",[]),"grade_scale":KB.get("grade_scale",[]),"metadata":KB.get("metadata",{}),"content":KB.get("content",{})})
    if path.endswith("/ask"):
        try:
            body=req.get("body") or "{}"
            data=json.loads(body) if isinstance(body,str) else body
            q=str(data.get("question","")).strip()
            if not q: return response(400,{"error":"اكتب السؤال الأول"})
            answer=local_search(q)
            key=os.environ.get("GEMINI_API_KEY","").strip()
            if key:
                try: answer=gemini(q,key)
                except Exception: pass
            return response(200,{"answer":answer})
        except Exception as e:
            return response(400,{"error":str(e)})
    return response(404,{"error":"Not found"})
