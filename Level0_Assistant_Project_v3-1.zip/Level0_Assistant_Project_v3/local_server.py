import http.server, os
PORT=int(os.environ.get("PORT","8080"))
ROOT=os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)
print(f"Level 0 Hub V3: http://localhost:{PORT}")
http.server.ThreadingHTTPServer(("127.0.0.1",PORT),http.server.SimpleHTTPRequestHandler).serve_forever()
